*** Maxime's bowling score calculator *** 

To use it, just run the jar file with line strings in parameters. 
Enjoy! 