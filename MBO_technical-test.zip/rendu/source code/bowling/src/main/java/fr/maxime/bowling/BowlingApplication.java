package fr.maxime.bowling;

import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Logger;
import  org.apache.log4j.LogManager;

public class BowlingApplication {

	private static Logger logger = LogManager.getLogger(BowlingApplication.class);
	public static void main(String[] args) {

		BasicConfigurator.configure();
		for(int argsIndex=0; argsIndex< args.length;argsIndex++)
			scoreCalculator(args[argsIndex]);


	}

	/***
	 * calculate bowling score for given line
	 * @param line
	 * @return score
	 */
	private static int scoreCalculator(String line)
	{
		int score = 0;
		int[] scorePerFrame = new int[10];
		boolean spare = false, strike = false, error = false;
		String[] frameList = null;

		logger.info("line : " + line);

		//line control
		if(lineCheck(line))
		{
			frameList = line.split(" ");

			//loop on frames
			for(int frameIndex=0;frameIndex<scorePerFrame.length;frameIndex++)
			{
				String currentFrame = frameList[frameIndex];

				//2 decimals or '-': simple addition
				if(currentFrame.matches("(\\d|-)(\\d|-)"))
				{
					String[] scoreTriesString = currentFrame.split("");

					//first try
					String currentTry = scoreTriesString[0];
					int currentScore=("-".equals(currentTry)?0:Integer.valueOf(currentTry));

					scorePerFrame[frameIndex]+=currentScore;

					//spare & strikes bonuses
					if(spare)
					{
						scorePerFrame[frameIndex-1]+=currentScore;
						spare=false;
					}

					if(strike)
					{
						scorePerFrame[frameIndex-1]+=currentScore;


						//double strike check
						if(frameIndex>=2 && "X".equals(frameList[frameIndex-2]))
						{
							scorePerFrame[frameIndex-2]+=currentScore;
						}

					}

					//second try
					currentTry = scoreTriesString[1];
					currentScore=("-".equals(currentTry)?0:Integer.valueOf(currentTry));

					scorePerFrame[frameIndex]+=currentScore;

					if(strike)
					{
						scorePerFrame[frameIndex-1]+=currentScore;
						strike=false;
					}


				}
				//spare cases
				else if (currentFrame.contains("/")||currentFrame.contains("\\"))
				{

					//there is necessary one try on spare cases
					String[] scoreTriesString = currentFrame.split("");
					String digit = scoreTriesString[0];
					int currentScoreFirstTry=("-".equals(digit)?0:Integer.valueOf(digit));

					//last frame were a spare or a strike
					if(spare)
					{
						scorePerFrame[frameIndex - 1] += currentScoreFirstTry;
					}
					if(strike) //or a strike
					{
						scorePerFrame[frameIndex - 1] += currentScoreFirstTry;
					}

					//this frame score
					scorePerFrame[frameIndex]+=10;
					spare=true;

					//exceptionnal third try (spare on 10th frame)
					if(scoreTriesString.length==3)
					{
						digit = scoreTriesString[2];
						currentScoreFirstTry=("-".equals(digit)?0:Integer.valueOf(digit));
						scorePerFrame[frameIndex] +=currentScoreFirstTry;
					}

				}


				else if("X".equals(currentFrame))//strike !
				{
					if(spare)
					{
						scorePerFrame[frameIndex-1]+=10;
						spare = false;
					}
					if(strike)
					{
						scorePerFrame[frameIndex-1]+=10;
						//useless but logic
						strike=false;

						//double strike check
						if(frameIndex>=2 && "X".equals(frameList[frameIndex-2]))
						{
							scorePerFrame[frameIndex-2]+=10;
						}
					}

					//this frame score
					scorePerFrame[frameIndex]+=10;
					strike=true;

					//exceptionnal case if strike happens one 10th frame
					if((frameIndex+1)==10)
					{
						//loop on last frames
						for(int specialFrameIndex=10;specialFrameIndex<frameList.length;specialFrameIndex++)
						{
							String specialFrame = frameList[specialFrameIndex];

							//double strike check
							if(specialFrameIndex==11 && "X".equals(frameList[frameIndex-2]))
							{
								scorePerFrame[frameIndex-1]+=10;
							}
							if("X".equals(specialFrame))
								scorePerFrame[9]+=10;
							else if(specialFrame.contains("/")||specialFrame.contains("\\"))
							{
								scorePerFrame[9]+=10;
								//special exceptionnal case
								if(specialFrame.length()==3)
								{
									String currentSpecialTry = specialFrame.split("")[2];
									int currentSpecialScore=("-".equals(currentSpecialTry)?0:Integer.valueOf(currentSpecialTry));
									scorePerFrame[9]+=currentSpecialScore;
								}

							}
							else //only digits
							{
								//first one
								String currentSpecialTry = specialFrame.split("")[0];
								int currentSpecialScore=("-".equals(currentSpecialTry)?0:Integer.valueOf(currentSpecialTry));
								scorePerFrame[9]+=currentSpecialScore;
								//second one
								currentSpecialTry = specialFrame.split("")[1];
								currentSpecialScore=("-".equals(currentSpecialTry)?0:Integer.valueOf(currentSpecialTry));
								scorePerFrame[9]+=currentSpecialScore;
							}

						}
					}

				}

				else //non recognized frame
				{
					logger.error("wrong frame format");
					error=true;
				}


			}

			//calculating global score
			for(int frameIndex=0;frameIndex<scorePerFrame.length;frameIndex++)
			{
				score+=scorePerFrame[frameIndex];
			}
			if(!error)
			{
				logger.info(frameScoreString(scorePerFrame));
				logger.info(cumulatedFrameScoreString(scorePerFrame) + "\n");
			}

		}
		else //error management
			logger.error("wrong line format\n");

		if(!error)
			return score;
		else
			return 0;
	}

	/***
	 * formatting frames' score
	 * @param scorePerFrame
	 * @return inline frame scores
	 */
	private static String frameScoreString(int[] scorePerFrame)
	{
		String output="score per frame : ";

		for(int index=0;index<scorePerFrame.length;index++)
			output += String.valueOf(scorePerFrame[index]) + " ";

		return output;
	}

	/***
	 * formatting cumulated frames' score
	 * @param scorePerFrame
	 * @return inline cumulated frame score
	 */
	private static String cumulatedFrameScoreString(int[] scorePerFrame)
	{
		String output="global score : ";

		int score = 0;
		for(int index=0;index<scorePerFrame.length;index++)
		{
			score += scorePerFrame[index];
			output += String.valueOf(score) + " ";
		}

		return output;
	}

	/***
	 * check if the line is correct
	 * @param line
	 * @return true : line OK; false : line KO
	 */
	private static boolean lineCheck(String line)
	{
		String[] splittedLine = line.split(" ");
		if(splittedLine.length==10||(splittedLine.length>=10&&"X".equals(splittedLine[9])))
			return true;
		else
			return false;
	}
}
